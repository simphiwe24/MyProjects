# Bootcamp Final Selector V.0.1

import unittest
from unittest.mock import patch
from io import StringIO
import sys
import os
import bootcamp_final_selector

class TestBootcampFinalSelector(unittest.TestCase):

    @patch("sys.stdin", StringIO("StudentA\n"))
    def test_user_name(self):
        output = StringIO()
        sys.stdout = output


        self.assertEqual(bootcamp_final_selector.user_name(), "StudentA")
        self.assertEqual(output.getvalue(), '''Enter username: ''')

    def test_read_file(self):

        boolean = os.path.isfile("student_results.txt")
        self.assertEqual(boolean, True,"Missing File 'student_results.txt' in current working directory!")

        student_results = bootcamp_final_selector.read_file("StudentA")
        
        self.assertTrue(isinstance(student_results,list))
        self.assertEqual(len(student_results),3)
        self.assertEqual(student_results[0],"StudentA - 50")
        self.assertEqual(student_results[1],"StudentA - 8")
        self.assertEqual(student_results[2],"StudentA - 18")


    def test_get_student_scores(self):

        student_results = [
            "StudentF - 43",
            "StudentF - 3",
            "StudentF - 12"
        ]

        student_scores = bootcamp_final_selector.get_student_scores(student_results)

        self.assertTrue(isinstance(student_scores,list))
        self.assertEqual(len(student_scores),3)
        self.assertEqual(student_scores[0],43)
        self.assertEqual(student_scores[1],3)
        self.assertEqual(student_scores[2],12)


    def test_exam_score(self):
        exam_score = bootcamp_final_selector.exam_score([30, 10, 20])
        self.assertEqual(exam_score, 30)


    def test_exam_percentage(self):
        exam_percentage = bootcamp_final_selector.exam_percentage([30, 10, 20])
        self.assertEqual(exam_percentage, 30)


    def test_group_project_score(self):
        exam_score = bootcamp_final_selector.group_project_score([30, 10, 20])
        self.assertEqual(exam_score, 10)


    def test_group_project_percentage(self):
        exam_percentage = bootcamp_final_selector.group_project_percentage([30, 10, 20])
        self.assertEqual(exam_percentage, 50)


    def test_daily_exercise_score(self):
        exam_score = bootcamp_final_selector.daily_exercise_score([30, 10, 20])
        self.assertEqual(exam_score, 20)


    def test_daily_exercise_percentage(self):
        exam_percentage = bootcamp_final_selector.daily_exercise_percentage([30, 10, 20])
        self.assertEqual(exam_percentage, 67)


    def test_final_result(self):
        final_result = bootcamp_final_selector.final_result(18, 10, 13)
        self.assertEqual(final_result, 29)


    def test_first_class_pass(self):
        type_pass = bootcamp_final_selector.type_of_pass(91)
        self.assertEqual(type_pass, "First Class Pass")

    
    def test_pass(self):
        type_pass = bootcamp_final_selector.type_of_pass(81)
        self.assertEqual(type_pass, "Pass")


    def test_fail(self):
        type_pass = bootcamp_final_selector.type_of_pass(20)
        self.assertEqual(type_pass, "Fail") 

if __name__ == '__main__':
    unittest.main()
